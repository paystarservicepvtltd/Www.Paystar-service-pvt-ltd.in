# Paystar Service Pvt Ltd — Company Website

This repository contains the static website for Paystar Service Pvt Ltd, built from the company profile PDF.

## Structure
- `index.html` — Single-file responsive site with embedded logo.
- `Paystar_Service_Profile_4Pages_Expanded2.pdf` — Original company profile.
- `.github/workflows/deploy.yml` — GitHub Actions workflow to publish to `gh-pages`.

## Deploy
This repo uses GitHub Actions (peaceiris/actions-gh-pages) to publish the repo root to the `gh-pages` branch on every push to `main`.

After pushing, go to **Settings → Pages** and ensure the site source is set to **gh-pages** branch (or let GitHub auto-select the published branch).

## Notes
- To enable contact form submissions, configure Formspree/Netlify Forms as described in `index.html`.
- Add a `CNAME` file (if you own a domain) with your domain name to enable a custom domain.
